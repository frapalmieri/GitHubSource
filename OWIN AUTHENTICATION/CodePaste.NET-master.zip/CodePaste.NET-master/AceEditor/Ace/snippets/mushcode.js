define('ace/snippets/mushcode', ['require', 'exports', 'module' ], function(require, exports, module) {


exports.snippetText = "";
exports.scope = "mushcode";

});
