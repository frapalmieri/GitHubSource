define('ace/snippets/batchfile', ['require', 'exports', 'module' ], function(require, exports, module) {


exports.snippetText = "";
exports.scope = "batchfile";

});
