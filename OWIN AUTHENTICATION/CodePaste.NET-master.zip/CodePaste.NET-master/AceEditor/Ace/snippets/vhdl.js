define('ace/snippets/vhdl', ['require', 'exports', 'module' ], function(require, exports, module) {


exports.snippetText = "";
exports.scope = "vhdl";

});