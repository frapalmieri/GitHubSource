﻿using System.ComponentModel.DataAnnotations;

namespace ServerSideLogin.Models
{
    public class LoginSuccessViewModel
    {
        public string HtmlForm { get; set; }
    }
}