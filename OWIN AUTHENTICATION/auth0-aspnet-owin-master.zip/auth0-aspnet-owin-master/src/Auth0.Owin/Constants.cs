﻿using System;

namespace Auth0.Owin
{
    internal static class Constants
    {
        public const string DefaultAuthenticationType = "Auth0";

        public const string Auth0Issuer = "auth0";
    }
}
